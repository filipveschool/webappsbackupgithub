<?php
/**
 * Created by PhpStorm.
 * User: filip
 * Date: 5/27/2016
 * Time: 6:35 PM
 */

$db = mysqli_connect('localhost','root','','webappsexamen');