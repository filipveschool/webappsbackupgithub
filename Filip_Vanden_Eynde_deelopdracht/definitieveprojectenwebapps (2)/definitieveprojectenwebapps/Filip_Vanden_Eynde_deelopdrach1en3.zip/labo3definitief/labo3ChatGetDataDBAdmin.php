<?php
/**
 * Created by PhpStorm.
 * User: filip
 * Date: 5/24/2016
 * Time: 10:16 AM
 */

$db = mysqli_connect('localhost','root','','webappsexamen');