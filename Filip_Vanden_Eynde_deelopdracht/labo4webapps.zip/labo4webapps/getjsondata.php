<?php
//header("Access-Control-Allow-Origin: *");
//header("Content-Type: application/json; charset=UTF-8");

$conn = mysqli_connect('localhost', 'root', '', 'webappsallelabos');

$result2 = $conn->query("SELECT productname, price from products");
/*
$outp = "";
while ($rs = $result->fetch_array(MYSQLI_ASSOC)) {
    if ($outp != "") {
        $outp .= ",";
    }
    $outp .= '{"id":"' . $rs["id"] . '",';
    $outp .= '"productname":"' . $rs["productname"] . '",';
    $outp .= '"price":"' . $rs["price"] . '"}';
}
$outp = '{"records":[' . $outp . ']}';
$conn->close();

echo($outp);

*/

$emparray = array();
while ($rowjson = mysqli_fetch_assoc($result2)) {
    $emparray[] = $rowjson;

}

$jsondata2 = json_encode($emparray);

echo $jsondata2;


