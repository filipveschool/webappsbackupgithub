var webSocket;
var messages = document.getElementById("messages");

function openSocket() {
	if (webSocket !== undefined && webSocket.readyState !== WebSocket.CLOSED) {
		writeResponse("WebSocket is already opened.");
		return;
	}
	webSocket = new WebSocket("ws://localhost:8080/labodriewebapps/echofilip");

	webSocket.onopen = function(event) {
		writeResponse("Connection opened")
	};

	webSocket.onmessage = function(event) {
		writeResponse(event.data);

	};

	webSocket.onclose = function(event) {
		writeResponse("Connection closed");
	};
}
function send() {
	var text = document.getElementById("messageinput").value;
	webSocket.send(text);
}

function closeSocket() {
	webSocket.close();
}

function writeResponse(text) {
	console.log(text);
	messages.innerHTML += "<br/>" + text;
}