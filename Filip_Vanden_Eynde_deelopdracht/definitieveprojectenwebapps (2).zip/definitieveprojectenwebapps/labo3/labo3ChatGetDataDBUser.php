<?php
/**
 * Created by PhpStorm.
 * User: filip
 * Date: 5/24/2016
 * Time: 10:17 AM
 */

$db = mysqli_connect('localhost','root','','webappsallelabos');