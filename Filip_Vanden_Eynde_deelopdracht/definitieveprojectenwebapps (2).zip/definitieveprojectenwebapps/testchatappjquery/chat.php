<?php
/**
 * Created by PhpStorm.
 * User: filip
 * Date: 5/24/2016
 * Time: 11:07 AM
 */

include 'db.php';

$query = "SELECT * FROM chat1 ORDER BY id DESC";
$run = $db->query($query);

//$array = $run ->fetch_array();
//echo json_encode($array);

$emparray = array();
while ($rowjson = mysqli_fetch_assoc($run)) {
    $emparray[] = $rowjson;

}

echo json_encode($emparray);

